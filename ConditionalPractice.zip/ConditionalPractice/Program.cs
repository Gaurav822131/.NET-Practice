﻿// using System;
// namespace practiceAssignment;
// class Program()
// {
//     static void Main()
//     {
//         HeightCalc.height();
//     }
// }



// using System;
// namespace practiceAssignment;
// class Program
// {
//     static void Main()
//     {
//         LargestNumber.Largest();
//     }
// }


// using System;
// namespace practiceAssignment;
// class Program
// {
//     static void Main()
//     {
//             LeapCheck.Leap();
//     }
// }



// using System;
// namespace practiceAssignment;
// class Program
// {
//     static void Main()
//     {
//             AdmissionEligibilty.Adm();
//     }
// }



// using System;
// namespace practiceAssignment;
// class Program
// {
//     static void Main()
//     {
//             ElectricityBill.Electricity();
//     }
// }


// using System;
// namespace practiceAssignment;
// class Program
// {
//     static void Main()
//     {
//             VowelCheck.Vowel();
//     }
// }




// using System;
// namespace practiceAssignment;
// class Program
// {
//     static void Main()
//     {
//             TriangleType.Triangle();
//     }
// }




//  using System;
// namespace practiceAssignment;
// class Program
// {
//     static void Main()
//     {
//             QuadrantaFinder.Quad();
//     }
// }


using System;
namespace practiceAssignment;
class Program
{
    static void Main()
    {
            GradeDiscriptor.Grade();
    }
}



