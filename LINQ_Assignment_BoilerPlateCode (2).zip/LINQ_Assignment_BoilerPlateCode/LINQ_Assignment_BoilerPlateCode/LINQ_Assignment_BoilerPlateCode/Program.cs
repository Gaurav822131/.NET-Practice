﻿using System;
using System.Collections.Generic;
using System.Linq;
using LINQ_Assignment_BoilerPlateCode.Repos;
using LINQ_Assignment_BoilerPlateCode.DTOs;
using LINQ_Assignment_BoilerPlateCode.Models;

namespace LINQ_Assignment_BoilerPlateCode
{
    class Program
    {
        static void Main(string[] args)
        {
            // =======================
            // SAMPLE DATA
            // =======================
            var employees = EmployeeRepo.SeedEmployees();
            var projects = ProjectRepo.SeedProjects();

            Console.WriteLine("LINQ Scenario Boilerplate Loaded\n");

            // CALLING ONLY COMPLETED LINQ METHODS
            GetHighEarningEmployees(employees);
            GetEmployeeNames(employees);

            bool hasHR = HasHREmployees(employees);
            Console.WriteLine($"\nAny HR Employees? : {hasHR}");

            var deptCounts = GetDepartmentWiseCount(employees);
            Console.WriteLine("\nDepartment-wise Employee Count:");
            foreach (var d in deptCounts)
            {
                Console.WriteLine($"{d.Department} : {d.Count}");
            }

            var highestPaid = GetHighestPaidEmployee(employees);
            Console.WriteLine($"\nHighest Paid Employee: {highestPaid.Name} | {highestPaid.Salary}");

            var sortedEmployees = SortEmployeesBySalaryAndName(employees);
            Console.WriteLine("\nEmployees Sorted by Salary DESC, Name ASC:");
            foreach (var e in sortedEmployees)
            {
                Console.WriteLine($"{e.Name} | {e.Salary}");
            }

            Console.ReadLine();
        }

        // =====================================================
        // 🟢 SECTION 1 – HR ANALYTICS
        // =====================================================
        // TODO 1.1: Get employees earning more than 60,000
        static List<Employee> GetHighEarningEmployees(List<Employee> employees)
        {
            var result =
                from e in employees
                where e.Salary > 60000
                select e;

            Console.WriteLine("Employees earning more than 60000:");
            foreach (var e in result)
            {
                Console.WriteLine($"{e.Id} | {e.Name} | {e.Department} | {e.Salary}");
            }

            return result.ToList();
        }

        // TODO 1.2: Get list of employee names only

        static List<string> GetEmployeeNames(List<Employee> employees)
        {
            var result =
                from e in employees
                select e.Name;

            Console.WriteLine("\nEmployee Names:");
            foreach (var name in result)
            {
                Console.WriteLine(name);
            }

            return result.ToList();
        }

        // TODO 1.3: Check if any employee belongs to HR department

        static bool HasHREmployees(List<Employee> employees)
        {
            var result =
                from e in employees
                where e.Department == "HR"
                select e;

            return result.Any();
        }

        // =====================================================
        // 🟡 SECTION 2 – MANAGEMENT INSIGHTS
        // =====================================================

        // TODO 2.1: Get department-wise employee count

        static List<DepartmentCount> GetDepartmentWiseCount(List<Employee> employees)
        {
            var result =
                from e in employees
                group e by e.Department into g
                select new DepartmentCount
                {
                    Department = g.Key,
                    Count = g.Count()
                };

            return result.ToList();
        }

        // TODO 2.2: Find the highest paid employee

        static Employee GetHighestPaidEmployee(List<Employee> employees)
        {
            var result =
                from e in employees
                orderby e.Salary descending
                select e;

            return result.FirstOrDefault();
        }

        // TODO 2.3: Sort employees by Salary(DESC), then Name(ASC)

        static List<Employee> SortEmployeesBySalaryAndName(List<Employee> employees)
        {
            var result =
                from e in employees
                orderby e.Salary descending, e.Name ascending
                select e;

            return result.ToList();
        }

        // 🔵 SECTION 3 – PROJECT & SKILL INTELLIGENCE
        // =====================================================

        // TODO 3.1: Join employees with projects
        static List<EmployeeProject> GetEmployeeProjectMappings(
            List<Employee> employees,
            List<Project> projects)
        {
            // TODO: Write LINQ query here
            throw new NotImplementedException();
        }

        // TODO 3.2: Find employees who are NOT assigned to any project
        static List<Employee> GetUnassignedEmployees(
            List<Employee> employees,
            List<Project> projects)
        {
            // TODO: Write LINQ query here
            throw new NotImplementedException();
        }

        // TODO 3.3: Get all unique skills across the organization
        static List<string> GetAllUniqueSkills(List<Employee> employees)
        {
            // TODO: Write LINQ query here
            throw new NotImplementedException();
        }

        // 🔴 SECTION 4 – ADVANCED WORKFORCE ANALYTICS
        // =====================================================

        // TODO 4.1: Get top 3 highest-paid employees per department
        static List<DepartmentTopEmployees> GetTopEarnersByDepartment(
            List<Employee> employees)
        {
            // TODO: Write LINQ query here
            throw new NotImplementedException();
        }

        // TODO 4.2: Remove duplicate employees based on Id
        static List<Employee> RemoveDuplicateEmployees(List<Employee> employees)
        {
            // TODO: Write LINQ query here
            throw new NotImplementedException();
        }

        // TODO 4.3: Implement pagination
        static List<Employee> GetEmployeesByPage(
            List<Employee> employees,
                    int pageNumber,
                    int pageSize = 5)
        {
            // TODO: Write LINQ query here
            throw new NotImplementedException();
        }
    }
}
